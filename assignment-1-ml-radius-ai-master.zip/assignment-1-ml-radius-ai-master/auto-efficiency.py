import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from tree.base import DecisionTree
from metrics import *
from ucimlrepo import fetch_ucirepo
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeRegressor

np.random.seed(42)

# fetch dataset
auto_mpg = fetch_ucirepo(id=9)

# data (as pandas dataframes)
X = pd.DataFrame(auto_mpg.data.features)
y = pd.DataFrame(auto_mpg.data.targets)
columns_names = X.columns.append(pd.Index(['output']))
data = pd.DataFrame(np.concatenate([X, y], axis=1), columns=columns_names)
data = data.dropna()

train_data = data.iloc[:int(0.75 * len(data)), :]
test_data = data.iloc[int(0.75 * len(data)):, :]

sklearn_tree = DecisionTreeRegressor()
x_train = train_data.iloc[:, :-1]
y_train = train_data.iloc[:, -1]
sklearn_tree.fit(x_train, y_train)
sklearn_prediction = sklearn_tree.predict(test_data.iloc[:, :-1])
print("Sklearn tree rmse:", rmse(sklearn_prediction, test_data.iloc[:, -1]))

OurTree = DecisionTree("numerical", None, max_depth=5)
OurTree.fit(train_data)
our_predictions = OurTree.predict(test_data.iloc[:, :-1])
test_data.index = range(0, len(test_data))
print("OurTree rmse:", rmse(our_predictions, test_data.iloc[:, -1]))
