from typing import Union
import numpy as np
import pandas as pd


def accuracy(y_hat: pd.Series, y: pd.Series) -> float:
    assert y_hat.size == y.size
    return (y_hat == y).mean()


def precision(y_hat: pd.Series, y: pd.Series, cls: Union[int, str]) -> float:
    if type(cls) == str:
        cls = y.unique().tolist().index(cls)
    true_positives = ((y_hat == cls) & (y == cls)).sum()
    false_positives = ((y_hat == cls) & (y != cls)).sum()
    if true_positives + false_positives == 0:
        return 0
    precision = true_positives / (true_positives + false_positives)
    return precision


def recall(y_hat: pd.Series, y: pd.Series, cls: Union[int, str]) -> float:
    assert len(y_hat) == len(y), "Inputs must have the same length"
    if type(cls) == str:
        assert cls in y.unique(), f"{cls} not present in y"
        cls = y.unique().tolist().index(cls)
    true_positive = sum((y_hat == cls) & (y == cls))
    false_negative = sum((y_hat != cls) & (y == cls))
    assert true_positive + false_negative != 0, "true_positive and false_negative must not be zero"
    recall = true_positive / (true_positive + false_negative)
    return recall


def rmse(y_hat: pd.Series, y: pd.Series) -> float:
    assert len(y_hat) == len(y)
    assert y_hat.dtype in ['float', 'int']
    assert y.dtype in ['float', 'int']
    rmse = (np.mean((y_hat - y) ** 2))**0.5
    return rmse


def mae(y_hat: pd.Series, y: pd.Series) -> float:
    assert len(y_hat) == len(y)
    assert y_hat.dtype in ['float', 'int']
    assert y.dtype in ['float', 'int']
    mae = (y_hat - y).abs().mean()
    return mae
