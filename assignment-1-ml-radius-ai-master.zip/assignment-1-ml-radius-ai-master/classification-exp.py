import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from tree.base import DecisionTree
from metrics import *
from sklearn.datasets import make_classification

np.random.seed(42)

# Code given in the question
X, y = make_classification(
    n_features=2, n_redundant=0, n_informative=2, random_state=1, n_clusters_per_class=2, class_sep=0.5)

# For plotting
plt.scatter(X[:, 0], X[:, 1], c=y)

# Write the code for Q2 a) and b) below. Show your results.
# Q2 a)
# Split the dataset into training and test sets
split_idx = int(0.7 * len(X))
X_train, y_train = X[:split_idx], y[:split_idx]
X_test, y_test = X[split_idx:], y[split_idx:]

# Create an instance of the DecisionTree class
decision_tree = DecisionTree(criterion="information_gain", max_depth=5)

# Train the decision tree on the training set
decision_tree.fit(X_train, y_train)

# Evaluate the decision tree on the test set
predictions = decision_tree.predict(X_test)

# Calculate and print metrics
accuracy_value = accuracy(predictions, y_test)
precision_value = precision(predictions, y_test, cls=1)  # Assuming binary classification, adjust if needed
recall_value = recall(predictions, y_test, cls=1)  # Assuming binary classification, adjust if needed

print(f"Accuracy: {accuracy_value}")
print(f"Precision (Class 1): {precision_value}")
print(f"Recall (Class 1): {recall_value}")

#Q2 b)

from sklearn.model_selection import cross_val_score

# Function to perform cross-validation and return mean accuracy
def cross_val_accuracy(depth):
    decision_tree = DecisionTree(criterion="information_gain", max_depth=depth)
    scores = cross_val_score(decision_tree, X, y, cv=5)
    return np.mean(scores)

# Test different depths using cross-validation
depths = list(range(1, 11))
mean_accuracies = [cross_val_accuracy(depth) for depth in depths]

# Find the depth with the highest mean accuracy
best_depth = depths[np.argmax(mean_accuracies)]

print(f"Optimal Depth found using 5-fold cross-validation: {best_depth}")


