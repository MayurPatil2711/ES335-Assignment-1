import pandas as pd
import numpy as np
import time
import matplotlib.pyplot as plt
from tree.base import DecisionTree
from metrics import *

np.random.seed(42)
num_average_time = 100


def data_generate(N, M, data_type=None):
    #this function generates dataset for given N and M based on data_type
    if data_type == "RIRO":
        X = pd.DataFrame(np.random.randn(N, M))
        y = pd.Series(np.random.randn(N))

    elif data_type == "RIDO":
        X = pd.DataFrame(np.random.randn(N, M))
        y = pd.Series(np.random.randint(2, size=N), dtype="category")

    elif data_type == "DIRO":
        X = pd.DataFrame({i: pd.Series(np.random.randint(M, size=N), dtype="category") for i in range(2)})
        y = pd.Series(np.random.randn(N))

    else:
        X = pd.DataFrame({i: pd.Series(np.random.randint(M, size=N), dtype="category") for i in range(2)})
        y = pd.Series(np.random.randint(2, size=N), dtype="category")

    return X, y


def fit_time_calc(N, M, data_type):
    # this function calculates time required to fit decision tree on dataset generated
    time_array = []
    # decide which variable is varying
    if isinstance(N, np.ndarray):
        vary = N
    else:
        vary = M
    # for each value in varying dataset, it generates dataset
    for i in range(len(vary)):
        if isinstance(N, np.ndarray):
            X, y = data_generate(N[i], M, data_type)
        if isinstance(M, np.ndarray):
            X, y = data_generate(N, M[i], data_type)
        data = X.assign(output=y)
        data.columns = data.columns.astype(str)
        train_data = data.iloc[:int(0.70 * len(data)), :]
        # time calculation for fitting decision tree
        start_time = time.time()
        for i in range(5):
            dtree = DecisionTree("numerical", None, max_depth=4)
            dtree.fit(train_data)
        end_time = time.time()
        time_array.append((end_time - start_time) / 5)
    return time_array


def time_plot_fit(N, M, data_type):
    time_array = fit_time_calc(N, M, data_type)
    if isinstance(N, np.ndarray):
        vary = N
    else:
        vary = M
    plt.plot(vary, time_array)
    plt.plot(vary, time_array, label="train")
    if isinstance(N, int):
        fix = "N"
        vary = "M"
    else:
        fix = "M"
        vary = "N"
    plt.title(f"train time Fix {fix} Vary {vary} of {data_type}")
    plt.legend()
    plt.show()


def predict_time_calc(N, M, data_type):
    time_array = []
    if isinstance(N, np.ndarray):
        vary = N
    else:
        vary = M
    for i in range(len(vary)):
        if isinstance(N, np.ndarray):
            X, y = data_generate(N[i], M, data_type)
        if isinstance(M, np.ndarray):
            X, y = data_generate(N, M[i], data_type)
        data = X.assign(output=y)
        data.columns = data.columns.astype(str)
        train_data = data.iloc[:int(0.70 * len(data)), :]
        test_data = data.iloc[int(0.70 * len(data)):, :]
        dtree = DecisionTree("numerical", None, max_depth=4)
        dtree.fit(train_data)

        start_time = time.time()
        for i in range((10)):
            dtree.predict(test_data)
        end_time = time.time()
        time_array.append((end_time - start_time) / 10)
    return time_array


def time_plot_predict(N, M, data_type):
    time_array = predict_time_calc(N, M, data_type)
    if isinstance(N, np.ndarray):
        vary = N
    else:
        vary = M
    plt.plot(vary, time_array, label="test")
    if isinstance(N, int):
        fix = "N"
        vary = "M"
    else:
        fix = "M"
        vary = "N"
    plt.title(f"test time Fix {fix} Vary {vary} of {data_type}")
    plt.legend()
    plt.show()


N = 100
M = np.arange(18, 65, 1)
time_plot_fit(N, M, "RIRO")
time_plot_predict(N, M, "RIRO")
plt.title("N->Fixed, M->Vary")

N = np.arange(19, 840, 1)
M = 5
time_plot_fit(N, M, "RIRO")
time_plot_predict(N, M, "RIRO")
plt.title("M->Fixed, N->Vary")


N = 100
M = np.arange(18, 65, 1)
time_plot_fit(N, M, "DIRO")
time_plot_predict(N, M, "DIRO")
plt.title("N->Fixed, M->Vary")

N = np.arange(19, 840, 1)
M = 5
time_plot_fit(N, M, "DIRO")
time_plot_predict(N, M, "DIRO")
plt.title("M->Fixed, N->Vary")


N = 100
M = np.arange(18, 65, 1)
time_plot_fit(N, M, "DIDO")
time_plot_predict(N, M, "DIDO")
plt.title("N->Fixed, M->Vary")

N = np.arange(19, 840, 1)
M = 5
time_plot_fit(N, M, "DIDO")
time_plot_predict(N, M, "DIDO")
plt.title("M->Fixed, N->Vary")


N = 100
M = np.arange(18, 65, 1)
time_plot_fit(N, M, "RIDO")
time_plot_predict(N, M, "RIDO")
plt.title("N->Fixed, M->Vary")

N = np.arange(19, 840, 1)
M = 5
time_plot_fit(N, M, "RIDO")
time_plot_predict(N, M, "RIDO")
plt.title("M->Fixed, N->Vary")
